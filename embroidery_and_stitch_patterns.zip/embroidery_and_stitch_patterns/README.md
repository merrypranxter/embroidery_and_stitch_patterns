# Embroidery & Stitch Patterns

Drawing with thread. Needle as pen, cloth as canvas.

This repository documents embroidery as **mark-making systems** — needle trajectories that create lines, dots, fills, and relief on a fabric ground.

## The Core Principle

Embroidery adds a second visual layer to existing cloth. The ground fabric remains; the thread creates pattern, texture, and meaning on top of it.

- **Ground fabric**: The base cloth receiving embroidery
- **Stitch path**: The trajectory of the needle
- **Thread weight**: Thickness of the embroidery yarn
- **Stitch density**: How close stitches are to each other
- **Directionality**: Stitch angle affects light reflection

## The Stitch Families

### Basic Stitches
- [Running stitch](pattern_families/running_stitch.md) — dashed line, simple traversal
- [Backstitch](pattern_families/backstitch.md) — solid line, no gaps
- [Satin stitch](pattern_families/satin_stitch.md) — dense parallel fills, smooth surface
- [Chain stitch](pattern_families/chain_stitch.md) — looped line, decorative edge
- [Stem stitch](pattern_families/stem_stitch.md) — rope-like line, curves well

### Knots & Dots
- [French knots](pattern_families/french_knots.md) — wrapped thread dots, dimensional
- [Bullion knots](pattern_families/bullion.md) — elongated wrapped dots
- [Seed stitches](pattern_families/seed_stitch.md) — scattered small dots

### Couching & Laid Work
- [Couching](pattern_families/couching.md) — thick thread held down by small stitches
- [Laid work](pattern_families/laid_work.md) — threads laid across surface, caught at intervals

### Counted / Grid Stitches
- [Cross-stitch](pattern_families/cross_stitch.md) — X-shaped stitches on evenweave grid
- [Blackwork](pattern_families/blackwork.md) — geometric reversible patterns, Holbein stitch
- [Assisi work](pattern_families/assisi.md) — voided cross-stitch, motif in background

### Regional / Traditional Styles
- [Crewelwork](pattern_families/crewel.md) — wool on linen, Jacobean florals
- [Tambour](pattern_families/tambour.md) — chain stitch from hook, fast, often beaded
- [Stumpwork](pattern_families/stumpwork.md) — raised dimensional embroidery
- [Goldwork](pattern_families/goldwork.md) — metal threads, couching-based
- [Kantha](pattern_families/kantha.md) — Bengali running stitch, narrative quilting
- [Sashiko](pattern_families/sashiko.md) — Japanese decorative reinforcement, geometric
- [Boro](pattern_families/boro.md) — visible mending, patch layering, running stitch

### Bead & Sequin
- [Bead embroidery](pattern_families/bead_embroidery.md) — beads as primary texture
- [Sequin work](pattern_families/sequin.md) — reflective disc attachment

### Quilting / Trapunto Adjacent
- [Quilting stitches](pattern_families/quilting_stitches.md) — through all layers, holding padding
- [Trapunto](pattern_families/trapunto.md) — stuffed quilting, dimensional relief

## Visual DNA of Embroidered Cloth

- **Raised surface**: Thread sits above ground fabric
- **Directional sheen**: Satin stitch reflects light at stitch angle
- **Knot texture**: French/bullion knots create dimensional dots
- **Thread color contrast**: Often different from ground fabric
- **Irregularity**: Hand embroidery has slight variation; machine is uniform

## Shader Translation: Embroidery-Specific Parameters

| Parameter | What It Controls | Range | Notes |
|-----------|---------------|-------|-------|
| `stitch_path` | Needle trajectory curve | — | Bezier or polyline |
| `stitch_length` | Distance between needle penetrations | 0.001–0.05 | In UV space |
| `thread_thickness` | Diameter of embroidery yarn | 0.001–0.03 | Thicker than sewing thread |
| `stitch_height` | Normal displacement from ground | 0.0–0.1 | 0 = flat, 0.1 = heavy trapunto |
| `fill_density` | Coverage percentage | 0.0–1.0 | 1.0 = solid satin stitch |
| `knot_size` | Diameter of French/bullion knot | 0.005–0.05 | UV space |
| `direction_angle` | Stitch alignment | 0°–180° | Affects specular highlight |

## Stitch-to-Shader Logic

### Running Stitch Line
```glsl
float running_stitch(vec2 uv, vec2 start, vec2 end, float stitch_len, float gap) {
    float dist = line_distance(uv, start, end);
    float along = line_projection(uv, start, end);
    float period = stitch_len + gap;
    float phase = fract(along / period);
    float visible = step(phase, stitch_len / period);
    return visible * smoothstep(thread_thickness, 0.0, dist);
}
```

### Satin Stitch Fill
```glsl
float satin_stitch(vec2 uv, vec2 bounds[4], float angle, float spacing) {
    vec2 rotated = rotate(uv, angle);
    float stripe = sin(rotated.x * PI / spacing);
    float inside = rect_contains(rotated, bounds);
    return inside * smoothstep(0.0, 0.1, stripe);
}
```

### French Knot
```glsl
float french_knot(vec2 uv, vec2 center, float size) {
    float dist = length(uv - center);
    float knot = smoothstep(size, 0.0, dist);
    float wrap = fbm((uv - center) * 50.0) * 0.3; // Thread wrap texture
    return knot * (0.7 + wrap);
}
```

## Prompt Templates

### Satin Stitch
> "Dense satin stitch embroidery in [COLOR] silk thread on [GROUND FABRIC], filling a [SHAPE] shape with perfectly parallel stitches at [ANGLE] degrees, slight sheen catching light, hand embroidery detail"

### Cross-Stitch
> "Traditional cross-stitch sampler in [COLOR COUNT] colors on white evenweave Aida cloth, showing [MOTIF] pattern in counted thread grid, each X visible, folk craft aesthetic"

### Kantha
> "Bengali kantha quilt with white running stitches on [COLOR] cotton sari layers, narrative patches showing [SCENES], dense quilting holding recycled fabrics together"

## Anti-Drift: Embroidery-Specific

- **Embroidery ≠ woven pattern**: Embroidery sits ON TOP of fabric; woven pattern IS the fabric
- **Cross-stitch requires evenweave**: If the grid isn't visible, it's not cross-stitch
- **Sashiko is running stitch, not satin**: Sashiko uses simple running stitch, not dense fill
- **Boro is mending, not decoration**: The stitches hold patches; the aesthetic is functional
- **Goldwork is couching**: Metal threads are too stiff to pass through fabric; they're laid and couched

---

*This repo treats embroidery as drawing with thread. The needle is the pen. The stitch is the stroke. The ground is the canvas.*
